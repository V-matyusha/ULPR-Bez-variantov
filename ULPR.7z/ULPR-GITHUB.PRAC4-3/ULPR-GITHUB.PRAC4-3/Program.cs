﻿using System;
using System.Globalization;
namespace n3
{
    class Program
    {
        static void Main(string[] args)
        {
            int years, leapyears, days, dayofweek;
            Console.WriteLine("Введите год:");
            int year = int.Parse(Console.ReadLine());

            years = year - 1900;
            leapyears = (years - 1) / 4;
            days = (years * 365 + leapyears);
            dayofweek = days % 7;

            if (dayofweek == 0) // пн
            {
                Console.WriteLine("");
                Console.WriteLine("Январь 25");
                Console.WriteLine("Февраль 22");
                Console.WriteLine("Март 29");
                Console.WriteLine("Апрель 26");
                Console.WriteLine("Май 31");
                Console.WriteLine("Июнь 28");
                Console.WriteLine("Июль 26");
                Console.WriteLine("Август 30");
                Console.WriteLine("Сентябрь 27");
                Console.WriteLine("Октябрь 25");
                Console.WriteLine("Ноябрь 29");
                Console.WriteLine("Декабрь 27");
            }
            else

            if (dayofweek == 1) // вт
            {
                Console.WriteLine("");
                Console.WriteLine("Январь 31");
                Console.WriteLine("Февраль 28");
                Console.WriteLine("Март 28");
                Console.WriteLine("Апрель 25");
                Console.WriteLine("Май 30");
                Console.WriteLine("Июнь 27");
                Console.WriteLine("Июль 25");
                Console.WriteLine("Август 29");
                Console.WriteLine("Сентябрь 26");
                Console.WriteLine("Октябрь 31");
                Console.WriteLine("Ноябрь 28");
                Console.WriteLine("Декабрь 26");
            }
            else

            if (dayofweek == 2) // ср
            {
                Console.WriteLine("");
                Console.WriteLine("Январь 30");
                Console.WriteLine("Февраль 27");
                Console.WriteLine("Март 26");
                Console.WriteLine("Апрель 30");
                Console.WriteLine("Май 28");
                Console.WriteLine("Июнь 25");
                Console.WriteLine("Июль 30");
                Console.WriteLine("Август 27");
                Console.WriteLine("Сентябрь 24");
                Console.WriteLine("Октябрь 29");
                Console.WriteLine("Ноябрь 26");
                Console.WriteLine("Декабрь 31");
            }
            else

            if (dayofweek == 3) // чт
            {
                Console.WriteLine("");
                Console.WriteLine("Январь 29");
                Console.WriteLine("Февраль 26");
                Console.WriteLine("Март 26");
                Console.WriteLine("Апрель 30");
                Console.WriteLine("Май 28");
                Console.WriteLine("Июнь 25");
                Console.WriteLine("Июль 30");
                Console.WriteLine("Август 27");
                Console.WriteLine("Сентябрь 24");
                Console.WriteLine("Октябрь 29");
                Console.WriteLine("Ноябрь 26");
                Console.WriteLine("Декабрь 31");
            }
            else

            if (dayofweek == 4) // пт
            {
                Console.WriteLine("");
                Console.WriteLine("Январь 28");
                Console.WriteLine("Февраль 25");
                Console.WriteLine("Март 25");
                Console.WriteLine("Апрель 29");
                Console.WriteLine("Май 27");
                Console.WriteLine("Июнь 24");
                Console.WriteLine("Июль 29");
                Console.WriteLine("Август 26");
                Console.WriteLine("Сентябрь 30");
                Console.WriteLine("Октябрь 28");
                Console.WriteLine("Ноябрь 25");
                Console.WriteLine("Декабрь 30");
            }
            else

            if (dayofweek == 5) // сб
            {
                Console.WriteLine("");
                Console.WriteLine("Январь 27");
                Console.WriteLine("Февраль 24");
                Console.WriteLine("Март 31");
                Console.WriteLine("Апрель 28");
                Console.WriteLine("Май 26");
                Console.WriteLine("Июнь 30");
                Console.WriteLine("Июль 28");
                Console.WriteLine("Август 25");
                Console.WriteLine("Сентябрь 29");
                Console.WriteLine("Октябрь 27");
                Console.WriteLine("Ноябрь 24");
                Console.WriteLine("Декабрь 29");
            }
            else

            if (dayofweek == 6) // вск
            {
                Console.WriteLine("");
                Console.WriteLine("Январь 26");
                Console.WriteLine("Февраль 23");
                Console.WriteLine("Март 30");
                Console.WriteLine("Апрель 27");
                Console.WriteLine("Май 25");
                Console.WriteLine("Июнь 29");
                Console.WriteLine("Июль 27");
                Console.WriteLine("Август 31");
                Console.WriteLine("Сентябрь 28");
                Console.WriteLine("Октябрь 26");
                Console.WriteLine("Ноябрь 30");
                Console.WriteLine("Декабрь 28");
            }
        }
    }
}