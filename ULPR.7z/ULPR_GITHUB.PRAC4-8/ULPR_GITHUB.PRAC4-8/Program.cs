﻿using System;
using System.Globalization;
namespace n8
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Введите число а: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите число b, которое больше а, как минимум на 100:");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("------------------------------------------------------");
            Console.WriteLine("Набор сгенерированных чисел:");
            Parallel.For(0, 100, x => Console.WriteLine((x = new Random().Next(a, b)) != 0 ? x.ToString() + "\n" : null));
        }
    }
}